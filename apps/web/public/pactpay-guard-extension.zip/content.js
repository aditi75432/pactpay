/*
 * PactPay Guard: content script.
 *
 * Runs in every page, stays silent unless the page looks like a checkout, then:
 *   1. reads the page with extract.js (code evidence)
 *   2. (optional) asks the background worker for a screenshot, for the AI cross-check
 *   3. sends the evidence to PactPay, which applies the shopper's rules with fixed code
 *   4. shows the verdict in a shadow-DOM card the page can't style or script
 *   5. if the verdict is DO NOT PAY, puts a speed bump in front of the page's pay buttons,
 *      so neither a person nor an AI agent clicks "Place order" by accident.
 *
 * Nothing is sent until a checkout is detected, and only the order summary, hidden text and (with a key) a screenshot.
 */
(function () {
  "use strict";
  if (window.top !== window || window.__pactpayGuardLoaded) return;
  window.__pactpayGuardLoaded = true;

  var X = window.PactPayExtract;
  var DEFAULTS = { baseUrl: "https://pactpay-brs1.onrender.com", key: "", budget: 40, autoCheck: true, screenshots: true, blockPay: true };
  var state = { settings: DEFAULTS, host: null, root: null, running: false, last: null, armed: false, detected: false };

  // ---------- settings ----------
  function loadSettings() {
    return new Promise(function (resolve) {
      try { chrome.storage.local.get(DEFAULTS, function (v) { state.settings = Object.assign({}, DEFAULTS, v); resolve(state.settings); }); }
      catch (e) { resolve(DEFAULTS); }
    });
  }

  // ---------- connect bridge (PactPay web app -> extension) ----------
  function appOrigin() { try { return new URL(state.settings.baseUrl).origin; } catch (e) { return null; } }
  function startBridge() {
    if (location.origin !== appOrigin()) return;
    window.postMessage({ source: "pactpay-guard-ext", type: "READY", version: chrome.runtime.getManifest().version }, location.origin);
    window.addEventListener("message", function (ev) {
      if (ev.source !== window || ev.origin !== location.origin) return;
      var d = ev.data;
      if (d && d.source === "pactpay-web" && d.type === "PING") { window.postMessage({ source: "pactpay-guard-ext", type: "READY", version: chrome.runtime.getManifest().version }, location.origin); return; }
      if (!d || d.source !== "pactpay-web" || d.type !== "CONNECT" || typeof d.key !== "string" || !/^ppk_[A-Za-z0-9_-]{43}$/.test(d.key)) return;
      chrome.storage.local.set({ key: d.key }, function () {
        state.settings.key = d.key;
        window.postMessage({ source: "pactpay-guard-ext", type: "CONNECTED" }, location.origin);
      });
    });
  }

  // ---------- overlay ----------
  var CSS = [
    ":host{all:initial}",
    "*{box-sizing:border-box;font-family:ui-sans-serif,system-ui,-apple-system,'Segoe UI',Roboto,sans-serif}",
    ".dock{position:fixed;right:20px;bottom:20px;z-index:2147483647;width:372px;max-width:calc(100vw - 24px);color:#14251f}",
    ".pill{display:flex;align-items:center;gap:10px;background:#102a22;color:#fff;border:0;border-radius:999px;padding:11px 16px 11px 12px;font:600 14px/1 ui-sans-serif,system-ui,sans-serif;cursor:pointer;box-shadow:0 10px 30px rgba(16,42,34,.35);margin-left:auto}",
    ".pill:hover{background:#17382d}.pill .dot{width:22px;height:22px;border-radius:50%;background:#caff53;color:#102a22;display:grid;place-items:center;font-size:13px;font-weight:800}",
    ".card{background:#fff;border:1px solid #dce4dd;border-radius:18px;box-shadow:0 18px 50px rgba(16,42,34,.28);overflow:hidden;animation:in .18s ease-out}",
    "@keyframes in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}",
    ".hd{display:flex;align-items:center;gap:8px;padding:12px 14px;background:#f3f5f2;border-bottom:1px solid #e4eae5;font-size:12px;font-weight:700;color:#4c5f57;letter-spacing:.02em}",
    ".hd b{color:#102a22;font-size:13px}.hd .sp{flex:1}.x{background:none;border:0;font-size:20px;line-height:1;color:#7c8882;cursor:pointer;padding:0 2px}",
    ".verdict{padding:16px 16px 12px}.verdict .big{font-size:21px;font-weight:800;letter-spacing:-.02em;line-height:1.15;margin:0 0 6px}",
    ".verdict p{margin:0;font-size:13px;line-height:1.5;color:#465a52}",
    ".v-safe{background:linear-gradient(#eaf7ec,#fff)}.v-safe .big{color:#1b6b34}",
    ".v-block{background:linear-gradient(#fdeceb,#fff)}.v-block .big{color:#a5281b}",
    ".v-unk{background:linear-gradient(#fff5df,#fff)}.v-unk .big{color:#8a5a00}",
    ".v-busy{background:#fff}.v-busy .big{color:#102a22}",
    ".money{margin:0 16px 10px;border:1px solid #e4eae5;border-radius:12px;padding:6px 12px;font-size:13px}",
    ".money div{display:flex;justify-content:space-between;padding:4px 0;color:#465a52}.money .t{border-top:1px solid #e4eae5;margin-top:3px;padding-top:7px;font-weight:800;color:#14251f;font-size:14px}",
    ".money .bad{color:#a5281b;font-weight:700}",
    ".sec{padding:0 16px 10px}.sec h4{margin:8px 0 6px;font-size:11px;letter-spacing:.07em;text-transform:uppercase;color:#7c8882}",
    ".find{border-left:3px solid #d94b3d;background:#fdf3f2;border-radius:6px;padding:8px 10px;margin-bottom:7px;font-size:12px;line-height:1.45;color:#5a1d16}",
    ".find b{display:block;color:#8a2a1e;margin-bottom:3px}.find q{display:block;color:#3b1410;font-style:normal;background:#fff;border-radius:4px;padding:5px 7px;margin:4px 0;word-break:break-word}",
    ".find small{color:#8a5a52}",
    ".why{margin:0;padding:0 0 0 16px;font-size:12px;line-height:1.5;color:#465a52}.why li{margin-bottom:4px}",
    ".foot{display:flex;gap:8px;align-items:center;padding:10px 14px 14px;border-top:1px solid #eef2ee}",
    ".btn{border:0;border-radius:10px;padding:9px 13px;font:700 13px/1 ui-sans-serif,system-ui,sans-serif;cursor:pointer;background:#102a22;color:#fff}.btn.sec2{background:#eef2ee;color:#102a22}",
    ".meta{font-size:11px;color:#7c8882;margin-left:auto;text-align:right;line-height:1.35}",
    ".spin{width:16px;height:16px;border:2.5px solid #cfd8d2;border-top-color:#102a22;border-radius:50%;display:inline-block;vertical-align:-3px;margin-right:8px;animation:r .8s linear infinite}@keyframes r{to{transform:rotate(360deg)}}",
    ".gate{position:fixed;inset:0;z-index:2147483646;background:rgba(16,42,34,.55);display:grid;place-items:center;backdrop-filter:blur(2px)}",
    ".gate .box{background:#fff;border-radius:18px;max-width:420px;padding:24px;box-shadow:0 24px 70px rgba(0,0,0,.4)}",
    ".gate h3{margin:0 0 8px;font-size:20px;color:#a5281b;letter-spacing:-.01em}.gate p{margin:0 0 16px;font-size:14px;line-height:1.55;color:#33453d}",
    ".gate .row{display:flex;gap:10px;justify-content:flex-end}.btn.danger{background:#fff;color:#a5281b;border:1px solid #e6b9b4}",
  ].join("");

  function el(tag, attrs, children) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) { if (k === "text") n.textContent = attrs[k]; else if (k === "class") n.className = attrs[k]; else n.setAttribute(k, attrs[k]); });
    (children || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  function usd(n, cur) { return n === null || n === undefined ? "not shown" : (cur === "EUR" ? "€" : cur === "GBP" ? "£" : cur === "INR" ? "₹" : "$") + Number(n).toFixed(2); }

  function ensureHost() {
    if (state.host && document.contains(state.host)) return state.root;
    state.host = document.createElement("div");
    state.host.id = "pactpay-guard-host";
    state.root = state.host.attachShadow({ mode: "closed" });
    var style = document.createElement("style"); style.textContent = CSS;
    state.root.appendChild(style);
    state.dock = el("div", { class: "dock" });
    state.root.appendChild(state.dock);
    document.documentElement.appendChild(state.host);
    return state.root;
  }
  function setHostVisible(visible) { if (state.host) state.host.style.display = visible ? "" : "none"; }
  function clearDock() { ensureHost(); while (state.dock.firstChild) state.dock.removeChild(state.dock.firstChild); }

  function showPill(text) {
    clearDock();
    var pill = el("button", { class: "pill", type: "button", "aria-label": "Check this checkout with PactPay Guard" }, [el("span", { class: "dot", text: "✓" }), document.createTextNode(text)]);
    pill.addEventListener("click", function () { runCheck(); });
    state.dock.appendChild(pill);
  }

  function header() {
    var close = el("button", { class: "x", type: "button", "aria-label": "Close", text: "×" });
    close.addEventListener("click", function () { showPill(state.last ? "PactPay Guard" : "Check this checkout"); });
    return el("div", { class: "hd" }, [el("span", { class: "dot", text: "✓", style: "background:#caff53;color:#102a22;border-radius:50%;width:20px;height:20px;display:grid;place-items:center;font-size:12px" }), el("b", { text: "PactPay Guard" }), el("span", { class: "sp" }), close]);
  }

  function showBusy(message) {
    clearDock();
    state.dock.appendChild(el("div", { class: "card" }, [header(), el("div", { class: "verdict v-busy" }, [el("p", { class: "big" }, [el("span", { class: "spin" }), document.createTextNode(message)]), el("p", { text: "Reading the real page: its itemized charges, its hidden text, and (if you've connected a key) a screenshot." })])]));
  }

  function showError(message) {
    clearDock();
    var retry = el("button", { class: "btn", type: "button", text: "Try again" });
    retry.addEventListener("click", function () { runCheck(); });
    state.dock.appendChild(el("div", { class: "card" }, [header(), el("div", { class: "verdict v-unk" }, [el("p", { class: "big", text: "Couldn't check this page" }), el("p", { text: message })]), el("div", { class: "foot" }, [retry])]));
  }

  function showVerdict(result) {
    var v = result.verdict, cls = v.outcome === "SAFE_TO_PAY" ? "v-safe" : v.outcome === "DO_NOT_PAY" ? "v-block" : "v-unk";
    var title = v.outcome === "SAFE_TO_PAY" ? "Safe to pay" : v.outcome === "DO_NOT_PAY" ? "Do not pay" : "Can't verify";
    var sub = v.outcome === "SAFE_TO_PAY" ? "Everything on this checkout matches the rules you approved." : v.outcome === "DO_NOT_PAY" ? "This checkout doesn't match what you approved. The pay button is on hold." : "Something couldn't be confirmed. Don't pay until it is.";
    var cur = v.observed.currency, ok = v.inspection.arithmetic;
    var money = el("div", { class: "money" }, [
      el("div", {}, [el("span", { text: "Item" }), el("span", { text: usd(v.observed.itemPrice, cur) })]),
      el("div", {}, [el("span", { text: "Shipping" }), el("span", { text: usd(v.observed.shipping, cur) })]),
      el("div", {}, [el("span", { text: "Tax" }), el("span", { text: usd(v.observed.tax, cur) })]),
    ]);
    if (v.observed.fees > 0) money.appendChild(el("div", { class: "bad" }, [el("span", { text: "Other fees" }), el("span", { text: usd(v.observed.fees, cur) })]));
    if (ok.gap !== null && Math.abs(ok.gap) > 0.02) money.appendChild(el("div", { class: "bad" }, [el("span", { text: "Not itemized" }), el("span", { text: usd(Math.abs(ok.gap), cur) })]));
    money.appendChild(el("div", { class: "t" }, [el("span", { text: "Total" }), el("span", { text: usd(v.observed.total, cur) })]));

    var children = [header(), el("div", { class: "verdict " + cls }, [el("p", { class: "big", text: title }), el("p", { text: sub })]), money];

    var blocking = v.findings.filter(function (f) { return f.blocking; });
    if (blocking.length) {
      var sec = el("div", { class: "sec" }, [el("h4", { text: "What it found" })]);
      blocking.slice(0, 3).forEach(function (f) {
        sec.appendChild(el("div", { class: "find" }, [el("b", { text: f.title }), el("q", { text: f.excerpt }), el("small", { text: "Hidden how: " + f.how + ". A person can't see this; an AI agent reading the page can." })]));
      });
      children.push(sec);
    }
    var reasons = v.reasons.filter(function (r) { return !/^Invisible text|^A charge is drawn/.test(r); }).slice(0, 4);
    if (reasons.length) {
      var ul = el("ul", { class: "why" }); reasons.forEach(function (r) { ul.appendChild(el("li", { text: r })); });
      children.push(el("div", { class: "sec" }, [el("h4", { text: "Why" }), ul]));
    }

    var again = el("button", { class: "btn sec2", type: "button", text: "Check again" });
    again.addEventListener("click", function () { runCheck(); });
    var open = el("button", { class: "btn", type: "button", text: "Open PactPay" });
    open.addEventListener("click", function () { window.open(state.settings.baseUrl + "/control-center", "_blank", "noopener"); });
    var readers = v.confidence === "cross-checked" ? "Code + AI screenshot agree on the money" : (result.mode === "quick" ? "Quick Guard · code reader only" : "Code reader only");
    var meta = el("div", { class: "meta" }, [document.createTextNode(readers), el("br"), document.createTextNode(result.rulesTitle || "")]);
    children.push(el("div", { class: "foot" }, [again, open, meta]));
    if (result.visionNote) children.push(el("div", { class: "sec", style: "padding-bottom:12px;font-size:11px;color:#7c8882" }, [document.createTextNode(result.visionNote)]));

    clearDock();
    state.dock.appendChild(el("div", { class: "card" }, children));
  }

  // ---------- pay-button speed bump ----------
  var PAY_RE = /^(place (your )?order|pay now|complete (your )?(purchase|order)|confirm (order|payment)|buy now|submit order|pay with|pay \$|pay €|pay £)/i;
  function isPayControl(node) {
    var c = node && node.closest ? node.closest("button, input[type=submit], input[type=button], a[role=button], [role=button], a") : null;
    if (!c) return null;
    var label = (c.value || c.textContent || c.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
    return PAY_RE.test(label) ? c : null;
  }
  var bypass = false;
  function onClickCapture(ev) {
    if (!state.armed || bypass || ev.target === state.host) return;
    var control = isPayControl(ev.target);
    if (!control) return;
    ev.preventDefault(); ev.stopImmediatePropagation(); ev.stopPropagation();
    showGate(control);
  }
  function showGate(control, form) {
    var gate = el("div", { class: "gate", role: "alertdialog", "aria-modal": "true" });
    var stay = el("button", { class: "btn", type: "button", text: "Don't pay" });
    var anyway = el("button", { class: "btn danger", type: "button", text: "I understand, pay anyway" });
    var box = el("div", { class: "box" }, [
      el("h3", { text: "PactPay Guard stopped this payment" }),
      el("p", { text: "This checkout doesn't match the rules you approved. If an AI agent is shopping for you, it was just stopped too." }),
      el("div", { class: "row" }, [anyway, stay]),
    ]);
    gate.appendChild(box); state.root.appendChild(gate);
    stay.addEventListener("click", function () { state.root.removeChild(gate); });
    anyway.addEventListener("click", function () {
      state.root.removeChild(gate); bypass = true;
      try { if (control) control.click(); else if (form && form.requestSubmit) form.requestSubmit(); } finally { setTimeout(function () { bypass = false; }, 0); }
    });
  }
  function arm(on) {
    if (on && !state.armed) { document.addEventListener("click", onClickCapture, true); document.addEventListener("submit", onSubmitCapture, true); }
    if (!on && state.armed) { document.removeEventListener("click", onClickCapture, true); document.removeEventListener("submit", onSubmitCapture, true); }
    state.armed = on;
  }
  function onSubmitCapture(ev) {
    if (!state.armed || bypass) return;
    var form = ev.target; if (!form || !form.querySelector) return;
    var pay = Array.prototype.slice.call(form.querySelectorAll("button, input[type=submit]")).some(function (b) { return PAY_RE.test((b.value || b.textContent || "").replace(/\s+/g, " ").trim()); });
    if (pay) { ev.preventDefault(); ev.stopImmediatePropagation(); showGate(null, form); }
  }

  // ---------- the check ----------
  function send(message) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.runtime.sendMessage(message, function (reply) {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          resolve(reply);
        });
      } catch (e) { reject(e); }
    });
  }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  /** Scrolls the order summary into view and hides the card, so the screenshot shows what the shopper sees at checkout. */
  async function captureScreenshot(summaryEl) {
    var y = window.scrollY, x = window.scrollX;
    try {
      setHostVisible(false);
      if (summaryEl && summaryEl.scrollIntoView) summaryEl.scrollIntoView({ block: "center", behavior: "instant" });
      await wait(220);
      var reply = await send({ type: "CAPTURE" });
      return reply && reply.ok ? reply.dataUrl : null;
    } catch (e) { return null; }
    finally { window.scrollTo(x, y); setHostVisible(true); }
  }

  async function runCheck() {
    if (state.running) return;
    state.running = true;
    try {
      await loadSettings();
      showBusy("Checking this checkout…");
      var found = X.extractEvidence(document, window, location);
      if (!found.evidence.dom.readable) {
        showError("I couldn't find an order total on this page. Open the final payment step and check again.");
        return;
      }
      var wantsShot = !!state.settings.key && state.settings.screenshots;
      var screenshot = wantsShot ? await captureScreenshot(found.summaryEl) : null;
      var reply = await send({ type: "GUARD_CHECK", url: location.href, evidence: found.evidence, screenshot: screenshot });
      if (!reply || !reply.ok) { showError((reply && reply.error) || "PactPay didn't answer. Check the server URL in the extension."); return; }
      state.last = reply.result;
      showVerdict(reply.result);
      arm(!!state.settings.blockPay && reply.result.verdict.outcome !== "SAFE_TO_PAY");
      try { chrome.runtime.sendMessage({ type: "BADGE", outcome: reply.result.verdict.outcome }); } catch (e) { /* ignore */ }
    } catch (e) {
      showError(String(e && e.message || e));
    } finally { state.running = false; }
  }

  // ---------- boot ----------
  async function boot() {
    await loadSettings();
    startBridge();
    if (location.origin === appOrigin() && !/^\/store\//.test(location.pathname)) return; // never guard PactPay's own app pages
    var found;
    try { found = X.detectCheckout(document, location); } catch (e) { return; }
    state.detected = found.isCheckout;
    if (!found.isCheckout) return;
    // Pay buttons are on hold from the moment a checkout is detected until a check says otherwise: unknown is never safe.
    if (state.settings.blockPay && state.settings.autoCheck) arm(true);
    showPill(state.settings.autoCheck ? "Checking checkout…" : "Check this checkout");
    if (state.settings.autoCheck) runCheck();
  }

  chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
    if (msg && msg.type === "RUN_CHECK") { runCheck(); sendResponse({ ok: true }); }
    if (msg && msg.type === "STATUS") sendResponse({ ok: true, detected: state.detected, last: state.last ? state.last.verdict.outcome : null });
  });

  if (document.readyState === "complete" || document.readyState === "interactive") boot();
  else document.addEventListener("DOMContentLoaded", boot);
})();
