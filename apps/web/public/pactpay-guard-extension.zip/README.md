# PactPay Guard (browser extension)

Checks the **real** checkout page before you, or your AI agent, pays. Works on any store.

## Install (30 seconds)
1. Download `pactpay-guard-extension.zip` from the app's **/extension** page and unzip it (or use this folder).
2. Open `chrome://extensions`, turn on **Developer mode**, click **Load unpacked**, pick the folder.
3. Open the demo store at `<your PactPay URL>/store`, choose a checkout, and watch Guard check it.

Optional: click the toolbar icon and paste your PactPay agent key (or use **Connect** on the /extension page) to apply your approved rules and add the AI screenshot cross-check. With no key, Quick Guard checks against a budget you set (default $40) using the code reader only. No model is called.

## What it catches
| Trick | Who can see it | How Guard catches it |
|---|---|---|
| Fee not itemized (total > its lines) | code and pixels | arithmetic on the itemized rows |
| Fee drawn by CSS (`::after`) | pixels only | reads CSS pseudo-content + screenshot cross-check |
| Invisible text telling an AI to ignore your budget | code only | hidden-text scan (opacity 0, off-screen, 0px font, same colour, clipped, comments, alt text) |
| Total over your budget | both | your approved rules |

The verdict (`SAFE_TO_PAY`, `DO_NOT_PAY`, `CANNOT_VERIFY`) is produced by fixed code on the PactPay server. A model only ever reads pixels, and its reading must agree with the page's code. Unknown is never safe.

## Privacy
Nothing leaves the browser until a page is detected as a checkout. Then only the order summary, hidden text and (with a key) one screenshot are sent. Screenshots and page text are never stored; Guard stores only host, path, verdict, amounts and findings, and only for keyed checks.

## Develop
```bash
npm install
npm test        # 19 tests: reader against the demo store, plus reader -> verdict end to end
npm run pack    # rebuild apps/web/public/pactpay-guard-extension.zip
```
