/* PactPay Guard: background service worker. Captures the tab and talks to PactPay. Never decides anything. */
const DEFAULTS = { baseUrl: "https://pactpay-brs1.onrender.com", key: "", budget: 40 };

async function settings() {
  const v = await chrome.storage.local.get(DEFAULTS);
  return { ...DEFAULTS, ...v, baseUrl: String(v.baseUrl || DEFAULTS.baseUrl).replace(/\/+$/, "") };
}

async function guardCheck(msg) {
  const s = await settings();
  const headers = { "content-type": "application/json" };
  const body = { url: msg.url, evidence: msg.evidence };
  if (s.key) headers.authorization = `Bearer ${s.key}`;
  else body.budget = Number(s.budget) || 40;
  if (msg.screenshot) body.screenshot = msg.screenshot;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 70000);
  try {
    const res = await fetch(`${s.baseUrl}/api/guard/check`, { method: "POST", headers, body: JSON.stringify(body), signal: controller.signal });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) return { ok: false, error: json.error || `PactPay returned ${res.status}.` };
    return { ok: true, result: json };
  } catch (e) {
    return { ok: false, error: e && e.name === "AbortError" ? "PactPay took too long to answer." : `Couldn't reach PactPay at ${s.baseUrl}.` };
  } finally { clearTimeout(timer); }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  if (msg.type === "CAPTURE") {
    chrome.tabs.captureVisibleTab(sender.tab ? sender.tab.windowId : undefined, { format: "jpeg", quality: 72 })
      .then((dataUrl) => sendResponse({ ok: true, dataUrl }))
      .catch((e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
    return true;
  }
  if (msg.type === "GUARD_CHECK") {
    guardCheck(msg).then(sendResponse);
    return true;
  }
  if (msg.type === "BADGE" && sender.tab) {
    const map = { SAFE_TO_PAY: ["✓", "#1b8a3c"], DO_NOT_PAY: ["!", "#c0392b"], CANNOT_VERIFY: ["?", "#b9770e"] };
    const [text, color] = map[msg.outcome] || ["", "#000"];
    chrome.action.setBadgeText({ tabId: sender.tab.id, text });
    chrome.action.setBadgeBackgroundColor({ tabId: sender.tab.id, color });
    return false;
  }
  return false;
});
