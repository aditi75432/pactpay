const $ = (id) => document.getElementById(id);
const DEFAULTS = { baseUrl: "https://pactpay-brs1.onrender.com", key: "", budget: 40, autoCheck: true, screenshots: true, blockPay: true };

async function load() {
  const s = { ...DEFAULTS, ...(await chrome.storage.local.get(DEFAULTS)) };
  $("key").value = s.key; $("budget").value = s.budget; $("baseUrl").value = s.baseUrl;
  $("autoCheck").checked = s.autoCheck; $("screenshots").checked = s.screenshots; $("blockPay").checked = s.blockPay;
  $("open").href = s.baseUrl;
  return s;
}
function setStatus(kind, text) { const el = $("status"); el.className = `status ${kind}`; $("statusText").textContent = text; }

async function test(s) {
  try {
    const res = await fetch(`${s.baseUrl.replace(/\/+$/, "")}/api/guard/status`, { headers: s.key ? { authorization: `Bearer ${s.key}` } : {} });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) return setStatus("bad", j.error || "That key isn't valid. Create a new one in PactPay.");
    if (j.connected) setStatus("ok", `Connected · ${j.rules.length} rules from your Purchase Pact${j.vision ? " · AI cross-check on" : ""}`);
    else setStatus("ok", "Quick Guard · code reader only (add a key for your rules + AI)");
  } catch { setStatus("bad", "Can't reach the PactPay server. Check the URL under Advanced."); }
}

async function save() {
  const s = {
    baseUrl: $("baseUrl").value.trim().replace(/\/+$/, "") || DEFAULTS.baseUrl, key: $("key").value.trim(),
    budget: Math.max(1, Number($("budget").value) || 40), autoCheck: $("autoCheck").checked, screenshots: $("screenshots").checked, blockPay: $("blockPay").checked,
  };
  await chrome.storage.local.set(s);
  $("open").href = s.baseUrl;
  await test(s);
}

async function checkNow() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  try { await chrome.tabs.sendMessage(tab.id, { type: "RUN_CHECK" }); window.close(); }
  catch { $("pageState").textContent = "Reload this tab once, then try again (the extension was installed after it opened)."; }
}

async function pageState() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  try {
    const r = await chrome.tabs.sendMessage(tab.id, { type: "STATUS" });
    $("pageState").textContent = r.detected ? "This page looks like a checkout." : "No checkout detected here. You can still try a check on the payment step.";
  } catch { $("pageState").textContent = "Open a store's checkout page to use Guard."; }
}

$("save").addEventListener("click", save);
$("check").addEventListener("click", checkNow);
for (const id of ["autoCheck", "screenshots", "blockPay"]) $(id).addEventListener("change", save);
load().then(test).then(pageState);
